+++
title = "Epistemicka perverze reflexivity"
description = "Tento článek je generován jako placeholder pro Epistemicka perverze reflexivity."
twitter_card = "summary_large_image"
twitter_title = "Epistemicka perverze reflexivity"
twitter_description = "Krátký popis pro Epistemicka perverze reflexivity."
og_title = "Epistemicka perverze reflexivity"
og_description = "Stručný popis pro Epistemicka perverze reflexivity."
+++

# Epistemicka perverze reflexivity {#epistemicka-perverze-reflexivity}

_(Tento článek bude brzy doplněn o plný obsah v autentickém stylu.)_

