+++
title = "Kognitivni autokanibalizace"
description = "Tento článek je generován jako placeholder pro Kognitivni autokanibalizace."
twitter_card = "summary_large_image"
twitter_title = "Kognitivni autokanibalizace"
twitter_description = "Krátký popis pro Kognitivni autokanibalizace."
og_title = "Kognitivni autokanibalizace"
og_description = "Stručný popis pro Kognitivni autokanibalizace."
+++

# Kognitivni autokanibalizace {#kognitivni-autokanibalizace}

_(Tento článek bude brzy doplněn o plný obsah v autentickém stylu.)_

