+++
title = "Kognitivni intermodularni dysfunkce"
description = "Tento článek je generován jako placeholder pro Kognitivni intermodularni dysfunkce."
twitter_card = "summary_large_image"
twitter_title = "Kognitivni intermodularni dysfunkce"
twitter_description = "Krátký popis pro Kognitivni intermodularni dysfunkce."
og_title = "Kognitivni intermodularni dysfunkce"
og_description = "Stručný popis pro Kognitivni intermodularni dysfunkce."
+++

# Kognitivni intermodularni dysfunkce {#kognitivni-intermodularni-dysfunkce}

_(Tento článek bude brzy doplněn o plný obsah v autentickém stylu.)_

